# forestscaling

This is a package that contains all the functions and plotting themes included in the data analysis and visualization pipeline for the "ForestLight" paper.

Created by QDR on 04 November 2019.
